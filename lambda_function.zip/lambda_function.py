import json
from search import search
    
def lambda_handler(event, context):
    seq = event['seq']
    print(f"SEQ is {seq}")
    result = search(seq) #requests.get("http://885d447e.ngrok.io/")
    return {
        'statusCode': 200,
        'body': json.dumps(result)
    }

